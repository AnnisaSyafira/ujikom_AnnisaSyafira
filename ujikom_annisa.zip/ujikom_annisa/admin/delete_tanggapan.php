<?php
require '../koneksi.php';
$id=$_GET['id'];

$sql=mysqli_query($koneksi, "DELETE FROM petugas WHERE id_tanggapan='$id' ");

if ($sql)
{
    ?>
    <script type="text/javascript">
        alert ('Data Berhasil Dihapus');
        window.location='admin.php?url=lihat_tanggapan';
        </script>
    
    <?php
}
?>