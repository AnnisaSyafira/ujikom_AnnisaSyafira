<?php
if (isset($_GET['url'])) {
    $url = $_GET['url'];

    switch ($url)
    {
        case 'tulis_pengaduan';
            include 'tulis_pengaduan.php';
            break;

        case 'lihat_pengaduan';
                include 'lihat_pengaduan.php';
                break;

        case 'detail_pengaduan';
            include 'detail_pengaduan.php';
            break;

            case 'lihat_tanggapan';
            include 'lihat_tanggapan.php';
            break;
    }
} 
else 
{

?>
Selamat Datang di APK Pengaduan Masyarakat ( yang di buat untuk melaporkan pelanggaran atau kejadian yang ada di sekitar kita)<br><br>
ANDA LOGIN SEBAGAI : <h2><b> <?php echo $_SESSION['nama'];


}
?>